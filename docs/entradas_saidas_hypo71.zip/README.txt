.DAT - hipocentros localizados no hypo71.
.LCR - dados de tempo de chegada no formato dr entrada para o hypo71 (ver manual do hypo71)
.MOD - modelo ded velocidades utilizado na localização dos hipocentros (ver manual do hypo71).
.CRD - coordendas das estações.
As coordenadas estão em graus e minutos.
Ex:
534.62S -> 5 graus; 34.62 minutos; sul 
3547.30W -> 35 graus; 47.30 minutos; oeste.

Confirme olhando no manual do hypo71.


